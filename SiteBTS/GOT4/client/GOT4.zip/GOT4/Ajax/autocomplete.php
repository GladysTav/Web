<?php
echo '["waza.wizi@sio-hautil.net","winie.lourson@sio-hautil.net","zorg.mechant@sio-hautil.net","zaza.lala@sio-hautil.net","glagla@hotmail.fr"]';
 
 
?>