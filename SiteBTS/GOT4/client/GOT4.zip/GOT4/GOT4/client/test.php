<?php
echo($_SERVER['SERVER_ADDR']);
echo($_SERVER['SERVER_NAME']);

