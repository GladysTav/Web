﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PPE4
{
  public partial class GestionPoste : Form
  {
    ConnectionMySQL connectionMySQL;
    DataTable dt = new DataTable();
    DataTable dtV = new DataTable();
    DataTable dtR = new DataTable();
    DataGridViewComboBoxColumn cbbReg = new DataGridViewComboBoxColumn();
    string place_dispo;
    string id_choix;
    string rang;

    public GestionPoste(ConnectionMySQL connectionMySQL1)
    {
      InitializeComponent();
      try
      {
        connectionMySQL = connectionMySQL1;
        string login = connectionMySQL.Executer("Select login from Utilisateur where Id_Utilisateur =\" " + connectionMySQL.login + "\"");
        lbUser.Text = login;
        connectionMySQL.Fermer();

        string idUser = connectionMySQL.Executer("SELECT id_Utilisateur FROM utilisateur WHERE login = '" + connectionMySQL.Login + "'");
        lbidUser.Text = idUser;
        connectionMySQL.Fermer();

        string role = connectionMySQL.Executer("Select statut from statut where id_statut = (select id_statut from utilisateur where id_utilisateur=\" " + connectionMySQL.login + "\")");
        connectionMySQL.Fermer();
      }
      catch (Exception exce) { MessageBox.Show("Erreur : " + exce, "Erreur"); }
    }

    private void GestionPoste_Load(object sender, EventArgs e)
    {
      try
      {
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        lbUser.Text = connectionMySQL.login;
        label4.Text = connectionMySQL.Executer("Select Statut from statut where Id_Statut =\" " + connectionMySQL.statut + "\"");
        connectionMySQL.Fermer();

        MySqlDataAdapter mysqlda = new MySqlDataAdapter("SELECT id_region, region AS Region, place_dispo FROM region WHERE place_dispo > 0 ORDER BY place_dispo DESC", connectionMySQL.maconnexion);
        mysqlda.Fill(dt);
        dgvRegion.DataSource = dt;

        dgvRegion.Columns[1].ReadOnly = true;
        dgvRegion.Columns[2].ReadOnly = true;
        dgvRegion.Columns[0].Visible = false;
        dgvRegion.Columns[2].Width = 160;

        cbRang.Items.Clear();
        cbRang.Items.Add("1");
        cbRang.Items.Add("2");
        cbRang.Items.Add("3");

        MySqlDataAdapter mysqlda1 = new MySqlDataAdapter("SELECT c.id_choix, r.region AS Region, c.Rang FROM choix c INNER JOIN region r ON c.id_region = r.id_region where c.Id_Utilisateur = " + lbidUser.Text + " ORDER BY c.Rang ASC", connectionMySQL.maconnexion);
        mysqlda1.Fill(dtV);
        dgvVoeuxEnreg.DataSource = dtV;

        dgvVoeuxEnreg.Columns[1].Width = 170;
        dgvVoeuxEnreg.Columns[2].Width = 70;
        dgvVoeuxEnreg.Columns[0].Visible = false;

        connectionMySQL.Fermer();

        lbidReg.Visible = false;
        lbidUser.Visible = false;
        label7.Visible = false;
        label9.Visible = false; 
      }
      catch (Exception exce) { MessageBox.Show("Erreur : " + exce, "Erreur"); }
    }

    private void btnDecon_Click(object sender, EventArgs e)
    {
      PageConnexion form1 = new PageConnexion();
      form1.Show();
      this.Hide();
    }

    private void btnHisto_Click(object sender, EventArgs e)
    {
      Historique form1 = new Historique(connectionMySQL);
      form1.Show();
      this.Hide();
    }

    private void dgvRegion_CellClick(object sender, DataGridViewCellEventArgs e)
    {
    }

    private void dgvRegion_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {


    }

    private void btnValid_Click(object sender, EventArgs e)
    {
      try
      {
        if (Convert.ToInt16(place_dispo) > 0)
        {
          string nbReg = connectionMySQL.Executer("SELECT COUNT(*) FROM choix WHERE Id_Utilisateur = " + lbidUser.Text);
          if (Convert.ToInt16(nbReg) <= 3)
          {
            string nbId = connectionMySQL.Executer("SELECT Count(*) FROM choix WHERE id_region = " + lbidReg.Text + " AND Id_Utilisateur = " + lbidUser.Text); //si le region exist
            string rang = connectionMySQL.Executer("SELECT Rang FROM choix WHERE id_region = " + lbidReg.Text + " AND Id_Utilisateur = " + lbidUser.Text); //stock le rang
            string idChoix = connectionMySQL.Executer("SELECT id_choix FROM choix WHERE id_region = " + lbidReg.Text + " AND Id_Utilisateur = " + lbidUser.Text); //recupère l'id_choix
            if (Convert.ToInt16(nbId) > 0)
            {
              string sUpdate = "UPDATE choix SET Rang = " + cbRang.SelectedItem + " WHERE id_choix = " + idChoix; //update rang
              connectionMySQL.Executer(sUpdate);
              string trouve = connectionMySQL.Executer("SELECT Count(*) FROM choix WHERE id_region != " + lbidReg.Text + " AND Id_Utilisateur = " + lbidUser.Text + " AND Rang = " + cbRang.SelectedItem); //verifier le doublant du rang                                                                                                                                                                                                          //string idChoix1 = connectionMySQL.Executer("SELECT id_choix FROM choix WHERE id_region != " + lbidReg.Text + " AND Id_Utilisateur = " + lbidUser.Text + " AND Rang = " + cbRang.SelectedItem); //recupère l'id_choix
              if (Convert.ToInt16(trouve) > 0)
              {
                if (Convert.ToInt16(rang) == 1)
                {
                  string sUpdateRang = "UPDATE choix SET Rang = Rang - 1 WHERE Id_Utilisateur = " + lbidUser.Text;
                  connectionMySQL.Executer(sUpdateRang);
                }
                else if (Convert.ToInt16(rang) == 2)
                {
                  string sUpdateRang = "UPDATE choix SET Rang = Rang - 1 WHERE ID_Utilisateur = " + lbidUser.Text + " AND Rang = 3";
                  connectionMySQL.Executer(sUpdateRang);
                }
              }
            }
            else
            {
              string sInsert = "INSERT INTO choix (Rang, Id_Utilisateur, id_region) VALUES (" + cbRang.SelectedItem + ", " + lbidUser.Text + ", " + lbidReg.Text + ")";

              if (Convert.ToInt16(cbRang.SelectedItem) == 1)
              {
                string sUpdateRang = "UPDATE choix SET Rang = Rang + 1 WHERE Id_Utilisateur = " + lbidUser.Text;
                connectionMySQL.Executer(sUpdateRang);
                connectionMySQL.Executer(sInsert);
              }
              else if (Convert.ToInt16(cbRang.SelectedItem) == 2)
              {
                string sUpdateRang = "UPDATE choix SET Rang = Rang + 1 WHERE ID_Utilisateur = " + lbidUser.Text + " AND Rang = 2";
                connectionMySQL.Executer(sUpdateRang);
                connectionMySQL.Executer(sInsert);
              }

              //string trouve1 = connectionMySQL.Executer("SELECT Count(*) FROM choix WHERE id_region != " + lbidReg.Text + " AND Id_Utilisateur = " + lbidUser.Text + " AND Rang = " + cbRang.SelectedItem); //verifier le doublant du rang
              //string idChoix2 = connectionMySQL.Executer("SELECT id_choix FROM choix WHERE id_region != " + lbidReg.Text + " AND Id_Utilisateur = " + lbidUser.Text + " AND Rang = " + cbRang.SelectedItem); //recupère l'id_choix
              //if (Convert.ToInt16(trouve1) > 0)
              //{
              //  string sDelete = "DELETE FROM choix WHERE id_choix = " + idChoix2;
              //  connectionMySQL.Executer(sDelete);
              //}
            }
          }         
          MessageBox.Show("La demande est enregistré!");
        }
        else
        {
          MessageBox.Show("La demande est refusé!");
        }

        connectionMySQL.Fermer();

        string sRefresh = "SELECT c.id_choix, r.region AS Region, c.Rang FROM choix c INNER JOIN region r ON c.id_region = r.id_region where c.Id_Utilisateur = " + lbidUser.Text + " ORDER BY c.Rang ASC";
        MySqlDataAdapter mysqlda = new MySqlDataAdapter(sRefresh, connectionMySQL.maconnexion);
        dtV.Clear();
        mysqlda.Fill(dtV);
        dgvVoeuxEnreg.DataSource = dtV;

        dgvVoeuxEnreg.Columns[0].Visible = false;
        connectionMySQL.Fermer();
      }
      catch (Exception exc) { MessageBox.Show("Erreur : " + exc, "Erreur"); }
    }

    private void dgvRegion_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      try
      {
        tbRegion.Text = dgvRegion.CurrentRow.Cells[1].Value.ToString();
        lbidReg.Text = dgvRegion.SelectedCells[0].Value.ToString();
        place_dispo = dgvRegion.CurrentRow.Cells[2].Value.ToString();

      }
      catch (Exception exc) { MessageBox.Show("Erreur : " + exc, "Erreur"); }
    }

    private void btnAnnul_Click(object sender, EventArgs e)
    {
      tbRegion.Text = "";
      cbRang.SelectedItem = null;
    }

    private void btnSup_Click(object sender, EventArgs e)
    {
      try
      {
        string sDelete = "DELETE FROM choix WHERE id_choix = " + Convert.ToInt16(id_choix);
        connectionMySQL.Executer(sDelete);
        string nbChoix = connectionMySQL.Executer("SELECT COUNT(*) FROM choix WHERE Id_Utilisateur = " + lbidUser.Text);
        if (Convert.ToInt16(nbChoix) > 0)
        {
          if (Convert.ToInt16(rang) != 0)
          {
            if (Convert.ToInt16(rang) == 1)
            {
              string sUpdate = "UPDATE choix SET Rang = Rang - 1 WHERE ID_Utilisateur = " + lbidUser.Text;
              connectionMySQL.Executer(sUpdate);
            }
            else if (Convert.ToInt16(rang) == 2)
            {
              string sUpdate = "UPDATE choix SET Rang = Rang - 1 WHERE ID_Utilisateur = " + lbidUser.Text + " AND Rang = 3";
              connectionMySQL.Executer(sUpdate);
            }
          }
        }
        MessageBox.Show("La suppression est affecté!");
        connectionMySQL.Fermer();

        MySqlDataAdapter mysqlda1 = new MySqlDataAdapter("SELECT c.id_choix, r.region AS Region, c.Rang FROM choix c INNER JOIN region r ON c.id_region = r.id_region where c.Id_Utilisateur = " + lbidUser.Text + " ORDER BY c.Rang ASC", connectionMySQL.maconnexion);
        dtV.Clear();
        mysqlda1.Fill(dtV);
        dgvVoeuxEnreg.DataSource = dtV;
        connectionMySQL.Fermer();
      }
      catch (Exception exc) { MessageBox.Show("Erreur : " + exc, "Erreur"); }


      string sRefresh = "SELECT c.id_choix, r.region AS Region, c.Rang FROM choix c INNER JOIN region r ON c.id_region = r.id_region where c.Id_Utilisateur = " + lbidUser.Text + " ORDER BY c.Rang ASC";
      MySqlDataAdapter mysqlda = new MySqlDataAdapter(sRefresh, connectionMySQL.maconnexion);
      dtV.Clear();
      mysqlda.Fill(dtV);
      dgvVoeuxEnreg.DataSource = dtV;
      connectionMySQL.Fermer();
    }

    private void dgvVoeuxEnreg_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {

    }

    private void dgvVoeuxEnreg_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      try
      {
        id_choix = dgvVoeuxEnreg.SelectedCells[0].Value.ToString();
        label7.Text = dgvVoeuxEnreg.SelectedCells[0].Value.ToString();
        rang = connectionMySQL.Executer("SELECT Rang FROM choix WHERE id_choix = " + Convert.ToInt16(id_choix));
        label9.Text = rang;
        connectionMySQL.Fermer();
      }
      catch (Exception exc) { MessageBox.Show("Erreur : " + exc, "Erreur"); }
    }
  }
}
