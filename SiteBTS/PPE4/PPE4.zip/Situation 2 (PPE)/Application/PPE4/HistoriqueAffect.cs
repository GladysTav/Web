﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PPE4
{
  public partial class HistoriqueAffect : Form
  {
    ConnectionMySQL connectionMySQL = new ConnectionMySQL();
    DataTable dt = new DataTable();
    public HistoriqueAffect(ConnectionMySQL connectionMySQL1)
    {
      InitializeComponent();
      try
      {
        connectionMySQL = connectionMySQL1;

        string login = connectionMySQL.Executer("Select login from Utilisateur where Id_Utilisateur =\" " + connectionMySQL.login + "\"");

        lbUser.Text = login;

        connectionMySQL.Fermer();

        string role = connectionMySQL.Executer("Select statut from statut where id_statut = (select id_statut from utilisateur where id_utilisateur=\" " + connectionMySQL.login + "\")");

        connectionMySQL.Fermer();
      }
      catch (Exception exc) { MessageBox.Show("Erreur : " + exc, "Erreur"); }
    }

    private void label1_Click(object sender, EventArgs e)
    {

    }

    private void HistoriqueAffect_Load(object sender, EventArgs e)
    {
      try
      {
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        lbUser.Text = connectionMySQL.login;
        label4.Text = connectionMySQL.Executer("Select Statut from statut where Id_Statut =\" " + connectionMySQL.statut + "\"");
        connectionMySQL.Fermer();

        MySqlDataAdapter mysqlda = new MySqlDataAdapter("SELECT r.region as Region, CONCAT(Nom, ' ', Prenom) AS Utilisateur, a.dateaff as Date_Affectation FROM affectation a, region r, utilisateur u WHERE a.Id_region = r.id_region AND a.Id_Utilisateur = u.Id_Utilisateur ORDER BY a.dateaff DESC", connectionMySQL.maconnexion);
        mysqlda.Fill(dt);
        dgvHistoVoeux.DataSource = dt;
        dgvHistoVoeux.Refresh();

        dgvHistoVoeux.Columns[0].Width = 150;
        dgvHistoVoeux.Columns[1].Width = 140;
        connectionMySQL.Fermer();
      }
      catch (Exception exc) { MessageBox.Show("Erreur : " + exc, "Erreur"); }
    }

    private void btnDecon_Click(object sender, EventArgs e)
    {
      PageConnexion form1 = new PageConnexion();
      form1.Show();
      this.Hide();
    }

    private void btnHisto_Click(object sender, EventArgs e)
    {
      gestionAffect form1 = new gestionAffect(connectionMySQL);
      form1.Show();
      this.Hide();
    }

    private void btnAccueil_Click(object sender, EventArgs e)
    {
      ListeRegion form1 = new ListeRegion(connectionMySQL);
      form1.Show();
      this.Hide();
    }

    private void label5_Click(object sender, EventArgs e)
    {

    }
  }
}
