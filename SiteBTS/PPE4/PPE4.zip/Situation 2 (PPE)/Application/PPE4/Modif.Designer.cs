﻿namespace PPE4
{
  partial class Modif
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.tbNbPlace = new System.Windows.Forms.TextBox();
      this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.lbRegion = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.btnAnnule = new System.Windows.Forms.Button();
      this.btnValide = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // tbNbPlace
      // 
      this.tbNbPlace.Location = new System.Drawing.Point(446, 167);
      this.tbNbPlace.Name = "tbNbPlace";
      this.tbNbPlace.Size = new System.Drawing.Size(100, 26);
      this.tbNbPlace.TabIndex = 0;
      // 
      // contextMenuStrip1
      // 
      this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
      this.contextMenuStrip1.Name = "contextMenuStrip1";
      this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(124, 119);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(139, 25);
      this.label1.TabIndex = 2;
      this.label1.Text = "Région choisi :";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.ForeColor = System.Drawing.Color.DarkCyan;
      this.label2.Location = new System.Drawing.Point(96, 38);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(512, 29);
      this.label2.TabIndex = 3;
      this.label2.Text = "Modification le nombre des places disponibles";
      this.label2.Click += new System.EventHandler(this.label2_Click);
      // 
      // lbRegion
      // 
      this.lbRegion.AutoSize = true;
      this.lbRegion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lbRegion.Location = new System.Drawing.Point(290, 121);
      this.lbRegion.Name = "lbRegion";
      this.lbRegion.Size = new System.Drawing.Size(48, 22);
      this.lbRegion.TabIndex = 4;
      this.lbRegion.Text = "label";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label4.Location = new System.Drawing.Point(124, 168);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(288, 25);
      this.label4.TabIndex = 5;
      this.label4.Text = "Le nombre de place disponible :";
      // 
      // btnAnnule
      // 
      this.btnAnnule.BackgroundImage = global::PPE4.Properties.Resources.gris;
      this.btnAnnule.Location = new System.Drawing.Point(380, 251);
      this.btnAnnule.Name = "btnAnnule";
      this.btnAnnule.Size = new System.Drawing.Size(139, 43);
      this.btnAnnule.TabIndex = 9;
      this.btnAnnule.Text = "Annuler";
      this.btnAnnule.UseVisualStyleBackColor = true;
      // 
      // btnValide
      // 
      this.btnValide.BackgroundImage = global::PPE4.Properties.Resources.vert;
      this.btnValide.Location = new System.Drawing.Point(157, 251);
      this.btnValide.Name = "btnValide";
      this.btnValide.Size = new System.Drawing.Size(139, 43);
      this.btnValide.TabIndex = 8;
      this.btnValide.Text = "Valider";
      this.btnValide.UseVisualStyleBackColor = true;
      // 
      // Modif
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(694, 393);
      this.Controls.Add(this.btnAnnule);
      this.Controls.Add(this.btnValide);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.lbRegion);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.tbNbPlace);
      this.Name = "Modif";
      this.Text = "Modif";
      this.Load += new System.EventHandler(this.Modif_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.TextBox tbNbPlace;
    private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label lbRegion;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Button btnValide;
    private System.Windows.Forms.Button btnAnnule;
  }
}