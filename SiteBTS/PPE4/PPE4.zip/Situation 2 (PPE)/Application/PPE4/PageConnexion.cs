﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace PPE4
{
  public partial class PageConnexion : Form
  {
    public PageConnexion()
    {
      InitializeComponent();
    }

    private void PageConnexion_Load(object sender, EventArgs e)
    {
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
        }

    private void btnCon_Click(object sender, EventArgs e)
    {
      try
      {
        ConnectionMySQL connectionMySQL = new ConnectionMySQL();
        connectionMySQL.Connection();

        string Id, pass;
        Id = tbLogin.Text;
        pass = tbMotp.Text;


        string rep = connectionMySQL.Executer("SELECT Id_Utilisateur FROM utilisateur WHERE Login=\"" + Id + "\"AND mdp =\"" + pass + "\";");
        if (rep != "")
        {
          string stat = connectionMySQL.Executer("Select id_statut from utilisateur where id_utilisateur=\"" + rep + "\";");
            string user = connectionMySQL.Executer("Select Login from utilisateur where id_utilisateur=\"" + rep + "\";");
                    connectionMySQL.login = user;
                    connectionMySQL.statut = stat;

                    if (connectionMySQL.statut == Convert.ToString('1')){
                        GestionPoste poste = new GestionPoste(connectionMySQL);
                        poste.Show();
                        this.Hide();
                    }
                    else if (connectionMySQL.statut == Convert.ToString('4')) {
                        gestionAffect affectation = new gestionAffect(connectionMySQL);
                        affectation.Show();
                        this.Hide();
                    }
                    else MessageBox.Show("Vous n'avez pas accès à cette application.");


                }
        else
          MessageBox.Show("Mauvais identifiants.");

      }
      catch (Exception excep) { MessageBox.Show("Vérifiez votre connexion internet \n" + Convert.ToString(excep), "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error); }

    }

    private void btnInscript_Click(object sender, EventArgs e)
    {
      Inscription form1 = new Inscription();
      form1.Show();

      this.Hide();
    }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
