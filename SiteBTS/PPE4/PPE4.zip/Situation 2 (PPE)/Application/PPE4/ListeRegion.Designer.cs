﻿namespace PPE4
{
  partial class ListeRegion
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ListeRegion));
      this.dgvRegion = new System.Windows.Forms.DataGridView();
      this.label6 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.panel1 = new System.Windows.Forms.Panel();
      this.btnDecon = new System.Windows.Forms.Button();
      this.lbUser = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.btnHisto = new System.Windows.Forms.Button();
      this.btnAccueil = new System.Windows.Forms.Button();
      this.label4 = new System.Windows.Forms.Label();
      this.btnValid = new System.Windows.Forms.Button();
      this.panel2 = new System.Windows.Forms.Panel();
      this.tbPlaceD = new System.Windows.Forms.TextBox();
      this.label8 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label7 = new System.Windows.Forms.Label();
      this.tbRegion = new System.Windows.Forms.TextBox();
      ((System.ComponentModel.ISupportInitialize)(this.dgvRegion)).BeginInit();
      this.panel1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
      this.panel2.SuspendLayout();
      this.SuspendLayout();
      // 
      // dgvRegion
      // 
      this.dgvRegion.AllowUserToAddRows = false;
      this.dgvRegion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvRegion.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
      this.dgvRegion.Location = new System.Drawing.Point(298, 98);
      this.dgvRegion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.dgvRegion.Name = "dgvRegion";
      this.dgvRegion.RowTemplate.Height = 28;
      this.dgvRegion.Size = new System.Drawing.Size(607, 546);
      this.dgvRegion.TabIndex = 3;
      this.dgvRegion.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRegion_CellClick);
      this.dgvRegion.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRegion_CellContentClick);
      this.dgvRegion.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRegion_CellContentDoubleClick);
      this.dgvRegion.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgvRegion_CellValidating);
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(294, 39);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(0, 20);
      this.label6.TabIndex = 5;
      // 
      // label5
      // 
      this.label5.BackColor = System.Drawing.Color.Transparent;
      this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label5.ForeColor = System.Drawing.Color.Navy;
      this.label5.Location = new System.Drawing.Point(407, 24);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(420, 39);
      this.label5.TabIndex = 10;
      this.label5.Text = "Gestion des postes par région";
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
      this.panel1.Controls.Add(this.btnDecon);
      this.panel1.Controls.Add(this.lbUser);
      this.panel1.Controls.Add(this.label2);
      this.panel1.Controls.Add(this.label1);
      this.panel1.Controls.Add(this.pictureBox1);
      this.panel1.Location = new System.Drawing.Point(17, 12);
      this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(201, 652);
      this.panel1.TabIndex = 13;
      // 
      // btnDecon
      // 
      this.btnDecon.BackgroundImage = global::PPE4.Properties.Resources.gris;
      this.btnDecon.Location = new System.Drawing.Point(22, 591);
      this.btnDecon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.btnDecon.Name = "btnDecon";
      this.btnDecon.Size = new System.Drawing.Size(158, 41);
      this.btnDecon.TabIndex = 3;
      this.btnDecon.Text = "Déconnexion";
      this.btnDecon.UseVisualStyleBackColor = true;
      this.btnDecon.Click += new System.EventHandler(this.btnDecon_Click);
      // 
      // lbUser
      // 
      this.lbUser.AutoSize = true;
      this.lbUser.Location = new System.Drawing.Point(18, 498);
      this.lbUser.Name = "lbUser";
      this.lbUser.Size = new System.Drawing.Size(51, 20);
      this.lbUser.TabIndex = 4;
      this.lbUser.Text = "label3";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.ForeColor = System.Drawing.Color.Navy;
      this.label2.Location = new System.Drawing.Point(18, 435);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(113, 22);
      this.label2.TabIndex = 3;
      this.label2.Text = "Utilisateur :";
      // 
      // label1
      // 
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.ForeColor = System.Drawing.Color.Navy;
      this.label1.Location = new System.Drawing.Point(8, 135);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(190, 172);
      this.label1.TabIndex = 2;
      this.label1.Text = "Gestion des demandes de mutation";
      this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
      // 
      // pictureBox1
      // 
      this.pictureBox1.Image = global::PPE4.Properties.Resources.logo_gsb;
      this.pictureBox1.Location = new System.Drawing.Point(14, 12);
      this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new System.Drawing.Size(174, 101);
      this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
      this.pictureBox1.TabIndex = 1;
      this.pictureBox1.TabStop = false;
      // 
      // btnHisto
      // 
      this.btnHisto.BackgroundImage = global::PPE4.Properties.Resources.gris;
      this.btnHisto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnHisto.Location = new System.Drawing.Point(1026, 98);
      this.btnHisto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.btnHisto.Name = "btnHisto";
      this.btnHisto.Size = new System.Drawing.Size(180, 68);
      this.btnHisto.TabIndex = 21;
      this.btnHisto.Text = "Gestion des affectations";
      this.btnHisto.UseVisualStyleBackColor = true;
      this.btnHisto.Click += new System.EventHandler(this.btnHisto_Click);
      // 
      // btnAccueil
      // 
      this.btnAccueil.BackgroundImage = global::PPE4.Properties.Resources.gris;
      this.btnAccueil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnAccueil.Location = new System.Drawing.Point(1026, 194);
      this.btnAccueil.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.btnAccueil.Name = "btnAccueil";
      this.btnAccueil.Size = new System.Drawing.Size(180, 68);
      this.btnAccueil.TabIndex = 20;
      this.btnAccueil.Text = "Historique des affectations";
      this.btnAccueil.UseVisualStyleBackColor = true;
      this.btnAccueil.Click += new System.EventHandler(this.btnAccueil_Click);
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.BackColor = System.Drawing.Color.Transparent;
      this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label4.ForeColor = System.Drawing.Color.Navy;
      this.label4.Location = new System.Drawing.Point(1152, 12);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(43, 22);
      this.label4.TabIndex = 22;
      this.label4.Text = "aaa";
      // 
      // btnValid
      // 
      this.btnValid.BackgroundImage = global::PPE4.Properties.Resources.gris;
      this.btnValid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnValid.Location = new System.Drawing.Point(1026, 582);
      this.btnValid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.btnValid.Name = "btnValid";
      this.btnValid.Size = new System.Drawing.Size(180, 62);
      this.btnValid.TabIndex = 23;
      this.btnValid.Text = "Valider";
      this.btnValid.UseVisualStyleBackColor = true;
      this.btnValid.Click += new System.EventHandler(this.btnValid_Click);
      // 
      // panel2
      // 
      this.panel2.Controls.Add(this.tbPlaceD);
      this.panel2.Controls.Add(this.label8);
      this.panel2.Controls.Add(this.label3);
      this.panel2.Controls.Add(this.label7);
      this.panel2.Controls.Add(this.tbRegion);
      this.panel2.Location = new System.Drawing.Point(973, 305);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(294, 236);
      this.panel2.TabIndex = 24;
      // 
      // tbPlaceD
      // 
      this.tbPlaceD.Location = new System.Drawing.Point(34, 178);
      this.tbPlaceD.Name = "tbPlaceD";
      this.tbPlaceD.Size = new System.Drawing.Size(142, 26);
      this.tbPlaceD.TabIndex = 4;
      // 
      // label8
      // 
      this.label8.AutoSize = true;
      this.label8.Location = new System.Drawing.Point(30, 139);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(131, 20);
      this.label8.TabIndex = 3;
      this.label8.Text = "Place disponible :";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(228, 14);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(51, 20);
      this.label3.TabIndex = 1;
      this.label3.Text = "label3";
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Location = new System.Drawing.Point(30, 36);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(68, 20);
      this.label7.TabIndex = 2;
      this.label7.Text = "Région :";
      // 
      // tbRegion
      // 
      this.tbRegion.Location = new System.Drawing.Point(34, 75);
      this.tbRegion.Multiline = true;
      this.tbRegion.Name = "tbRegion";
      this.tbRegion.Size = new System.Drawing.Size(228, 45);
      this.tbRegion.TabIndex = 0;
      // 
      // ListeRegion
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
      this.ClientSize = new System.Drawing.Size(1338, 681);
      this.Controls.Add(this.panel2);
      this.Controls.Add(this.btnValid);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.btnHisto);
      this.Controls.Add(this.btnAccueil);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.label5);
      this.Controls.Add(this.label6);
      this.Controls.Add(this.dgvRegion);
      this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.Name = "ListeRegion";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "ListeRegion";
      this.Load += new System.EventHandler(this.ListeRegion_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgvRegion)).EndInit();
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
      this.panel2.ResumeLayout(false);
      this.panel2.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion
    private System.Windows.Forms.DataGridView dgvRegion;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnDecon;
        private System.Windows.Forms.Label lbUser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnHisto;
        private System.Windows.Forms.Button btnAccueil;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnValid;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.TextBox tbPlaceD;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.TextBox tbRegion;
  }
}