﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PPE4
{
  public partial class gestionAffect : Form
  {
    ConnectionMySQL connectionMySQL = new ConnectionMySQL();
    DataTable dt = new DataTable();
    DataTable dte = new DataTable();
    DataGridViewButtonColumn btnAffecter = new DataGridViewButtonColumn();
    public gestionAffect(ConnectionMySQL connectionMySQL1)
    {
      InitializeComponent();

      try
      {
        connectionMySQL = connectionMySQL1;

        string login = connectionMySQL.Executer("Select login from Utilisateur where Id_Utilisateur =\" " + connectionMySQL.login + "\"");

        lbUser.Text = login;

        connectionMySQL.Fermer();

        string role = connectionMySQL.Executer("Select statut from statut where id_statut = (select id_statut from utilisateur where id_utilisateur=\" " + connectionMySQL.login + "\")");

        connectionMySQL.Fermer();
      }
      catch (Exception exce) { MessageBox.Show("Erreur : " + exce, "Erreur"); }
    }

    private void panel2_Paint(object sender, PaintEventArgs e)
    {

    }

    private void gestionAffect_Load(object sender, EventArgs e)
    {
      try
      {
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        lbUser.Text = connectionMySQL.login;
        label4.Text = connectionMySQL.Executer("Select Statut from statut where Id_Statut =\" " + connectionMySQL.statut + "\"");
        connectionMySQL.Fermer();

        MySqlDataAdapter mysqlda = new MySqlDataAdapter("SELECT c.Id_Utilisateur, r.id_region, c.id_choix, r.place_dispo, CONCAT(Nom, ' ', Prenom) AS Utilisateur, region AS Region, Rang FROM choix c INNER JOIN region r ON c.id_region = r.id_region INNER JOIN utilisateur u ON c.id_utilisateur = u.id_utilisateur ORDER BY u.DateEntree ASC", connectionMySQL.maconnexion);       
        mysqlda.Fill(dt);
        dgvGestVoeux.DataSource = dt;

        dgvGestVoeux.Columns[0].Visible = false;
        dgvGestVoeux.Columns[1].Visible = false;
        dgvGestVoeux.Columns[2].Visible = false;
        dgvGestVoeux.Columns[3].Visible = false;

        dgvGestVoeux.Columns[4].ReadOnly = true;
        dgvGestVoeux.Columns[5].ReadOnly = true;
        dgvGestVoeux.Columns[6].ReadOnly = true;

        btnAffecter.Name = "Valider";
        btnAffecter.HeaderText = "Valider";
        btnAffecter.Text = "Affecter";
        btnAffecter.UseColumnTextForButtonValue = true;
        dgvGestVoeux.Columns.Insert(7, btnAffecter);

        dgvGestVoeux.Columns[4].Width = 150;
        dgvGestVoeux.Columns[5].Width = 155;
        dgvGestVoeux.Columns[6].Width = 80;
        connectionMySQL.Fermer();
      }
      catch (Exception exce) { MessageBox.Show("Erreur : " + exce, "Erreur"); }
      
      try
      {
        cbUser.Items.Clear();
        string sUser = "SELECT CONCAT(Nom, ' ', Prenom) AS Utilisateur FROM utilisateur";
        
        MySqlDataAdapter mysqlda = new MySqlDataAdapter(sUser, connectionMySQL.maconnexion);
        DataSet ds = new DataSet();
        mysqlda.Fill(ds);

        foreach (DataRow dr in ds.Tables[0].Rows)
        {
          cbUser.Items.Add(dr["Utilisateur"]);
        }
        connectionMySQL.Fermer();

      }
      catch (Exception exce) { MessageBox.Show("Erreur : " + exce, "Erreur"); }

      try
      {
        cbReg.Items.Clear();
        string sRegion = "SELECT region FROM region";
        MySqlDataAdapter mysqlda = new MySqlDataAdapter(sRegion, connectionMySQL.maconnexion);
        DataSet ds = new DataSet();
        mysqlda.Fill(ds);

        foreach (DataRow dr in ds.Tables[0].Rows)
        {
          cbReg.Items.Add(dr["region"]);
        }
        connectionMySQL.Fermer();
      }
      catch (Exception exce) { MessageBox.Show("Erreur : " + exce, "Erreur"); }

      //try
      //{
      //  cbAnnee.Items.Clear();
      //  cbAnnee.Items.Add("2018");
      //  cbAnnee.Items.Add("2019");
      //  cbAnnee.Items.Add("2020");
      //}
      //catch (Exception exce) { MessageBox.Show("Erreur : " + exce, "Erreur"); }

      
    }

    private void btnDecon_Click(object sender, EventArgs e)
    {
      PageConnexion form1 = new PageConnexion();
      form1.Show();
      this.Hide();
    }

    private void btnAffecter_Click(object sender, EventArgs e)
    {
        PageConnexion form1 = new PageConnexion();
        form1.Show();
        this.Hide();
    }

        private void btnHisto_Click(object sender, EventArgs e)
    {
      HistoriqueAffect form1 = new HistoriqueAffect(connectionMySQL);
      form1.Show();
      this.Hide();
    }

    private void btnAccueil_Click(object sender, EventArgs e)
    {
      ListeRegion form1 = new ListeRegion(connectionMySQL);
      form1.Show();
      this.Hide();
    }

    private void dgvGestVoeux_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      try
      {
        string iduser = dgvGestVoeux.Rows[dgvGestVoeux.SelectedCells[0].RowIndex].Cells[0].Value.ToString();
        string idreg = dgvGestVoeux.Rows[dgvGestVoeux.SelectedCells[0].RowIndex].Cells[1].Value.ToString();
        string idchoix = dgvGestVoeux.Rows[dgvGestVoeux.SelectedCells[0].RowIndex].Cells[2].Value.ToString();
        string place_dispo = dgvGestVoeux.Rows[dgvGestVoeux.SelectedCells[0].RowIndex].Cells[3].Value.ToString();

        if (dgvGestVoeux.Rows[dgvGestVoeux.SelectedCells[0].RowIndex].Cells[7].Selected)
        {
          string sInsert = "INSERT INTO affectation (dateaff, Id_Utilisateur, id_region) VALUES (CURRENT_TIMESTAMP," + iduser + "," + idreg + ")";
          string sUpdate = "UPDATE region SET place_dispo = place_dispo - 1 WHERE id_region = " + idreg;
          string sDelete = "DELETE FROM choix WHERE Id_choix = " + idchoix;
          string sRefresh = "SELECT c.Id_Utilisateur, r.id_region, c.id_choix, r.place_dispo, CONCAT(Nom, ' ', Prenom) AS Utilisateur, region AS Region, Rang FROM choix c INNER JOIN region r ON c.id_region = r.id_region INNER JOIN utilisateur u ON c.id_utilisateur = u.id_utilisateur ORDER BY u.DateEntree ASC";

          if (Convert.ToInt32(place_dispo) > 0)
          {
            connectionMySQL.Executer(sInsert);
            connectionMySQL.Executer(sUpdate);
            MessageBox.Show("La demande est enregistrée !");
          }
          else
          {
            MessageBox.Show("La region demandée est indisponible!");
          }
          connectionMySQL.Executer(sDelete);
          connectionMySQL.Executer(sRefresh);

          connectionMySQL.Fermer();

          MySqlDataAdapter mysqlda = new MySqlDataAdapter(sRefresh, connectionMySQL.maconnexion);
          dt.Clear();
          mysqlda.Fill(dt);
          dgvGestVoeux.DataSource = dt;

          connectionMySQL.Fermer();
        }

      }
      catch (Exception exce) { MessageBox.Show("Erreur : " + exce, "Erreur"); }
    }

    private void btnFiltre_Click(object sender, EventArgs e)
    {
      try
      {
        string sIdUser = connectionMySQL.Executer("SELECT Id_Utilisateur FROM utilisateur WHERE CONCAT(Nom, ' ', Prenom) LIKE '" + cbUser.SelectedItem + "'");
        string sIdReg = connectionMySQL.Executer("SELECT id_region FROM region WHERE region = '" + cbReg.SelectedItem + "'");
        connectionMySQL.Fermer();
        string where = " WHERE ";

        string sSearch = "SELECT c.Id_Utilisateur, r.id_region, c.id_choix, r.place_dispo, CONCAT(Nom, ' ', Prenom) AS Utilisateur, region as Region, Rang FROM choix c INNER JOIN region r ON c.id_region = r.id_region INNER JOIN utilisateur u ON c.id_utilisateur = u.id_utilisateur";

        if (cbUser.SelectedItem != null)
        {
          if (where != " WHERE ")
          {
            where += " AND u.Id_Utilisateur = " + sIdUser;
          }
          else
          {
            where += "u.Id_Utilisateur = " + sIdUser;
          }
        }
        
        if (cbReg.SelectedItem != null)
        {
          if (where != " WHERE ")
          {
            where += " AND r.id_region = " + sIdReg;
          }
          else
          {
            where += "r.id_region = " + sIdReg;
          }
        }

        //if (cbAnnee.SelectedItem != null) //date ne reconnait pas
        //{
        //  if (where != " WHERE ")
        //  {
        //    where += " AND c.date LIKE '" + cbAnnee.SelectedItem + "%'";
        //  }
        //  else
        //  {
        //    where += "c.date LIKE " + cbAnnee.SelectedItem;
        //  }
        //}

        sSearch = sSearch + where;

        //DateTime dtD = DateTime.MinValue;
        //DateTime dtF = DateTime.MinValue;
        connectionMySQL.Fermer();

        dt.Clear();
        MySqlDataAdapter mysqlda = new MySqlDataAdapter(sSearch, connectionMySQL.maconnexion);
             
        mysqlda.Fill(dt);
        dgvGestVoeux.DataSource = dt;

        connectionMySQL.Fermer();
      }
      catch (Exception exce) { MessageBox.Show("Erreur : " + exce, "Erreur"); }
    }

    private void label5_Click(object sender, EventArgs e)
    {

    }

    private void label6_Click(object sender, EventArgs e)
    {

    }

    //private void fillregion()
    //{
    //  try
    //  {
    //    cbReg.Items.Clear();

    //    string sRegion = "SELECT id_region, region FROM region";
    //    MySqlDataAdapter mysqlda = new MySqlDataAdapter(sRegion, connectionMySQL.maconnexion);
    //    DataSet ds = new DataSet();
    //    mysqlda.Fill(ds);

    //    foreach (DataRow dr in ds.Tables[1].Rows)
    //    {
    //      cbReg.Items.Add(dr["region"]);
    //    }
    //    connectionMySQL.Fermer();
    //  }
    //  catch (Exception exce) { MessageBox.Show("Erreur : " + exce, "Erreur"); }
    //}
  }
}
