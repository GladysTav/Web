﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PPE4
{
  public partial class Historique : Form
  {
    ConnectionMySQL connectionMySQL = new ConnectionMySQL();
    DataTable dt = new DataTable();
    public Historique(ConnectionMySQL connectionMySQL1)
    {
      InitializeComponent();
      connectionMySQL = connectionMySQL1;


    }

    private void Historique_Load(object sender, EventArgs e)
    {
      try
      {
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        lbUser.Text = connectionMySQL.login;
        label4.Text = connectionMySQL.Executer("Select Statut from statut where Id_Statut =\" " + connectionMySQL.statut + "\"");
        connectionMySQL.Fermer();


        MySqlDataAdapter mysqlda = new MySqlDataAdapter("select dateaff as Date, region as Region from region r natural join affectation a where a.id_utilisateur=(select id_utilisateur from utilisateur where login='" + connectionMySQL.Login + "')", connectionMySQL.maconnexion);
        mysqlda.Fill(dt);
        dgvHisto.DataSource = dt;
        dgvHisto.Refresh();

        dgvHisto.Columns[0].Width = 150;
        dgvHisto.Columns[1].Width = 200;
        connectionMySQL.Fermer();
      }
      catch (Exception exc) { MessageBox.Show("Erreur : " + exc, "Erreur"); }
    }

    private void btnFermer_Click(object sender, EventArgs e)
    {
      GestionPoste form1 = new GestionPoste(connectionMySQL);
      form1.Show();
      this.Hide();
    }

    private void btnDecon_Click(object sender, EventArgs e)
    {
      PageConnexion form1 = new PageConnexion();
      form1.Show();
      this.Hide();
    }

    private void dgvHisto_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {

    }
  }
}
