﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace PPE4
{
  public partial class Inscription : Form
  {
    public Inscription()
    {
      InitializeComponent();
    }

    private void Inscription_Load(object sender, EventArgs e)
    {
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.FormBorderStyle = FormBorderStyle.FixedDialog;
    }

    private void btnInscript_Click(object sender, EventArgs e)
    {
      try
      {
        var nom = tbNom.Text;
        var prenom = tbPrenom.Text;
        var mail = tbMail.Text;
        var login = tbLogin.Text;
        var mdp1 = tbMotp.Text;
        var mdp2 = tbCMotp.Text;

        bool arobase = false;
        foreach (char c in mail)
        {
          if (Convert.ToString(c) == "@") { arobase = true; }
        }
        foreach (char c in mail)
        {
          if (Convert.ToString(c) == " ") { arobase = false; }
        }

        bool maj = false, min = false, special = false, num = false;
        string mdpmaj = mdp1.ToUpper();
        string mdpmin = mdp1.ToLower();
        for (int i = 0; i < mdp1.Length; i++)
        {
          char lettre = mdp1[i];
          if (lettre == mdpmaj[i])
            maj = true;
          if (lettre == mdpmin[i])
            min = true;
          if (!char.IsLetterOrDigit(lettre))
            special = true;
          try
          {
            Convert.ToInt32(lettre);
            num = true;
          }
          catch
          {
          }
        }

        int nb = 0;
        if (maj) { nb = nb + 1; }
        if (min) { nb = nb + 1; }
        if (special) { nb = nb + 1; }
        if (num) { nb = nb + 1; }

        if (mdp1 != mdp2)
          MessageBox.Show("Le mot de passe est différent de sa confirmation", "Erreur", MessageBoxButtons.OK);
        else if (login.Length < 6)
          MessageBox.Show("Merci d'entrer un identifiant de plus de 6 caractères", "Erreur");
        else if (mdp1.Length < 8)
          MessageBox.Show("Merci d'entrer un mot de passe de 8 caractères ou plus", "Erreur");
        else if (prenom == "")
          MessageBox.Show("Merci de renseigner votre prenom", "Erreur");
        else if (nom == "")
          MessageBox.Show("Merci de renseigner votre nom", "Erreur");
        else if (mail == "" || arobase == false)
          MessageBox.Show("Merci de renseigner un mail valide", "Erreur");
        else if (checkBox1.Checked == false)
          MessageBox.Show("Merci d'accepter les conditions d'utilisation", "Erreur");

        else if (nb > 2)
        {
          ConnectionMySQL connectionMySQL = new ConnectionMySQL();

          connectionMySQL.Connection();

          string rep = connectionMySQL.Executer("INSERT INTO `utilisateur`  (`Nom`, `Prenom`, `Email`, `login`, `mdp`, `Id_statut`,`DateEntree`) VALUES ('" + nom + "', '" + prenom + "', '" + mail + "', '" + login + "', '" + mdp1 + "', " + 1 + ", '" + DateTime.Now.ToString("yyyy-MM-dd") + "');");


          MessageBox.Show("Inscription confirmée !", "Confirmation");

          this.Hide();
          PageConnexion form1 = new PageConnexion();
          form1.Show();
        }

        else
        {
          MessageBox.Show("Le mot de passe doit contenir au moins 3 caractères parmis : minuscule, majuscule, chiffre, caractère spécial.", "Erreur mot de passe");
        }
      }
      catch (Exception exc)
      {
        MessageBox.Show("Erreur : veuillez vérifier les informations et réessayer.\n\n" + exc, "Erreur");
      }
    }

    private void btnAnnul_Click(object sender, EventArgs e)
    {
      PageConnexion form1 = new PageConnexion();
      form1.Show();
      this.Hide();
    }
  }
}