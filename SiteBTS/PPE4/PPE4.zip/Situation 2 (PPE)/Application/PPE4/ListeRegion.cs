﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PPE4
{
  public partial class ListeRegion : Form
  {
    ConnectionMySQL connectionMySQL = new ConnectionMySQL();
    DataSet ds = new DataSet();
    DataTable dt = new DataTable();
    DataGridViewTextBoxColumn tbPlace = new DataGridViewTextBoxColumn();
    ListeRegion obj = (ListeRegion)Application.OpenForms["ListeRegion"];
    public ListeRegion(ConnectionMySQL connectionMySQL1)
    {
      InitializeComponent();
      try
      {
        connectionMySQL = connectionMySQL1;


        string login = connectionMySQL.Executer("Select login from Utilisateur where Id_Utilisateur =\" " + connectionMySQL.login + "\"");

        lbUser.Text = login;

        connectionMySQL.Fermer();

        //  string role = connectionMySQL.Executer("Select statut from statut where id_statut = (select id_statut from utilisateur where id_utilisateur=\" " + connectionMySQL.login + "\")");

        connectionMySQL.Fermer();
        //lbStatut.Text = role;
      }
      catch (Exception exc) { MessageBox.Show("Erreur : " + exc, "Erreur"); }
    }

    private void ListeRegion_Load(object sender, EventArgs e)
    {
      try
      {
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        lbUser.Text = connectionMySQL.login;
        label4.Text = connectionMySQL.Executer("Select Statut from statut where Id_Statut =\" " + connectionMySQL.statut + "\"");
        connectionMySQL.Fermer();

        MySqlDataAdapter mysqlda = new MySqlDataAdapter("SELECT id_region, region as Region, place_dispo as Place_disponible FROM region", connectionMySQL.maconnexion);
        mysqlda.Fill(dt);
        dgvRegion.DataSource = dt;
        dgvRegion.Refresh();

        dgvRegion.Columns[0].Visible = false;
        dgvRegion.Columns[1].Width = 220;
        dgvRegion.Columns[2].Width = 130;

        label3.Visible = false;
        tbRegion.ReadOnly = true;

        connectionMySQL.Fermer();
      }
      catch (Exception exc) { MessageBox.Show("Erreur : " + exc, "Erreur"); }
    }

    private void btnDecon_Click(object sender, EventArgs e)
    {
      PageConnexion form1 = new PageConnexion();
      form1.Show();
      this.Hide();
    }

    private void btnAccueil_Click(object sender, EventArgs e)
    {
      HistoriqueAffect form1 = new HistoriqueAffect(connectionMySQL);
      form1.Show();
      this.Hide();
    }

    private void btnHisto_Click(object sender, EventArgs e)
    {
      gestionAffect form1 = new gestionAffect(connectionMySQL);
      form1.Show();
      this.Hide();
    }

    private void dgvRegion_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {

    }

    private void dgvRegion_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
    {


    }

    private void dgvRegion_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      try
      {
        label3.Text = dgvRegion.CurrentRow.Cells[0].Value.ToString();
        tbRegion.Text = dgvRegion.CurrentRow.Cells[1].Value.ToString();
        tbPlaceD.Text = dgvRegion.CurrentRow.Cells[2].Value.ToString();
      }
      catch (Exception exc) { MessageBox.Show("Erreur : " + exc, "Erreur"); }
    }

    private void dgvRegion_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
    {

    }

    private void dgvRegion_UpdateEventHandler()
    {

    }

    private void dgvRegion_Cellclick(object sender, DataGridViewCellEventArgs e)
    {

      tbRegion.Text = dgvRegion.CurrentRow.Cells[1].Value.ToString();
      tbPlaceD.Text = dgvRegion.SelectedCells[2].Value.ToString();

    }
    private void btnValid_Click(object sender, EventArgs e)
    {
      string place_dispo = tbPlaceD.Text;
      string idreg = label3.Text;
      try
      {
        string sUpdate = "UPDATE region SET place_dispo = " + place_dispo + " WHERE id_region = " + Convert.ToInt16(idreg);
        connectionMySQL.Executer(sUpdate);
        MessageBox.Show("La modification est effectuée !");

      }
      catch (Exception exc) { MessageBox.Show("Erreur : " + exc, "Erreur"); }
      connectionMySQL.Fermer();

      MySqlDataAdapter mysqlda = new MySqlDataAdapter("SELECT id_region, region as Region, place_dispo as Place_disponible FROM region", connectionMySQL.maconnexion);
      dt.Clear();
      mysqlda.Fill(dt);
      dgvRegion.DataSource = dt;
      connectionMySQL.Fermer();
    }
  }
}
