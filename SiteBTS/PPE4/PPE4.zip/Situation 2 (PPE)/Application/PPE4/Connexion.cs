﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PPE4
{
  public class ConnectionMySQL
  {
    public string maRequette;
    public MySqlDataReader reader;
    public MySqlConnection maconnexion;
    public string login, statut;


    public string Login
    {
      get
      {
        return login;
      }
      set
      {
        login = value;
      }

    }



    public string Statut
    {
      get
      {
        return statut;
      }
      set
      {
        statut = value;
      }
    }

    public void Connection()
    {
      //try
      //{
      string maChaineConnexion = @"SERVER=127.0.0.1; DATABASE=GladysPPE; UID=root;PASSWORD=";
      maconnexion = new MySqlConnection(maChaineConnexion);
      maconnexion.Open();
      //}
      //catch (Exception){ MessageBox.Show("Vérifiez votre connexion internet", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);

      //}
    }

    public string Executer(string req)
    {
      maRequette = req;

      Fermer();
      Connection();

      MySqlCommand OleDbCommand = maconnexion.CreateCommand();
      OleDbCommand.Connection = maconnexion;
      OleDbCommand.CommandType = CommandType.Text;
      OleDbCommand.CommandText = maRequette;

      reader = OleDbCommand.ExecuteReader();
      bool a = reader.Read();
      if (a == true)
      {
        //MessageBox.Show(Convert.ToString(reader.GetString(0)));
        // return Convert.ToString(reader.GetString(0));
        return Convert.ToString(reader.GetValue(0));
      }
      else

        return "";
    }

    public MySqlDataReader Requete(string requete)
    {
      maRequette = requete;

      Fermer();
      Connection();

      MySqlCommand OleDbCommand = maconnexion.CreateCommand();
      OleDbCommand.Connection = maconnexion;
      OleDbCommand.CommandType = CommandType.Text;
      OleDbCommand.CommandText = maRequette;

      reader = OleDbCommand.ExecuteReader();

      return reader;

    }

    public void ExecuterBD()
    {
      Connection();
      MySqlCommand cmd = new MySqlCommand(maRequette, maconnexion);
      reader = cmd.ExecuteReader();
    }

    //public static DataSet FillData(string sQuery, List<MySqlParameter> MYSQLParams)
    //{
    //  return FillData(sQuery, MYSQLParams);
    //}

    public void Fermer()
    {
      maconnexion.Close();
    }
  }
}
