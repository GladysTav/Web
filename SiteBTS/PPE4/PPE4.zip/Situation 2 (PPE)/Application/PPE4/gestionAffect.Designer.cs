﻿namespace PPE4
{
  partial class gestionAffect
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(gestionAffect));
      this.panel1 = new System.Windows.Forms.Panel();
      this.btnDecon = new System.Windows.Forms.Button();
      this.lbUser = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.dgvGestVoeux = new System.Windows.Forms.DataGridView();
      this.btnAccueil = new System.Windows.Forms.Button();
      this.btnHisto = new System.Windows.Forms.Button();
      this.label5 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.cbUser = new System.Windows.Forms.ComboBox();
      this.label3 = new System.Windows.Forms.Label();
      this.panel2 = new System.Windows.Forms.Panel();
      this.btnFiltre = new System.Windows.Forms.Button();
      this.cbReg = new System.Windows.Forms.ComboBox();
      this.label6 = new System.Windows.Forms.Label();
      this.lbUserU = new System.Windows.Forms.Label();
      this.panel1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgvGestVoeux)).BeginInit();
      this.panel2.SuspendLayout();
      this.SuspendLayout();
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
      this.panel1.Controls.Add(this.btnDecon);
      this.panel1.Controls.Add(this.lbUser);
      this.panel1.Controls.Add(this.label2);
      this.panel1.Controls.Add(this.label1);
      this.panel1.Controls.Add(this.pictureBox1);
      this.panel1.Location = new System.Drawing.Point(12, 12);
      this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(201, 652);
      this.panel1.TabIndex = 3;
      // 
      // btnDecon
      // 
      this.btnDecon.BackgroundImage = global::PPE4.Properties.Resources.gris;
      this.btnDecon.Location = new System.Drawing.Point(22, 591);
      this.btnDecon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.btnDecon.Name = "btnDecon";
      this.btnDecon.Size = new System.Drawing.Size(158, 41);
      this.btnDecon.TabIndex = 3;
      this.btnDecon.Text = "Déconnexion";
      this.btnDecon.UseVisualStyleBackColor = true;
      this.btnDecon.Click += new System.EventHandler(this.btnDecon_Click);
      // 
      // lbUser
      // 
      this.lbUser.AutoSize = true;
      this.lbUser.Location = new System.Drawing.Point(18, 498);
      this.lbUser.Name = "lbUser";
      this.lbUser.Size = new System.Drawing.Size(51, 20);
      this.lbUser.TabIndex = 4;
      this.lbUser.Text = "label3";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.ForeColor = System.Drawing.Color.Navy;
      this.label2.Location = new System.Drawing.Point(18, 435);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(113, 22);
      this.label2.TabIndex = 3;
      this.label2.Text = "Utilisateur :";
      // 
      // label1
      // 
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.ForeColor = System.Drawing.Color.Navy;
      this.label1.Location = new System.Drawing.Point(8, 135);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(190, 172);
      this.label1.TabIndex = 2;
      this.label1.Text = "Gestion des demandes de mutation";
      this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
      // 
      // pictureBox1
      // 
      this.pictureBox1.Image = global::PPE4.Properties.Resources.logo_gsb;
      this.pictureBox1.Location = new System.Drawing.Point(14, 12);
      this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new System.Drawing.Size(174, 101);
      this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
      this.pictureBox1.TabIndex = 1;
      this.pictureBox1.TabStop = false;
      // 
      // dgvGestVoeux
      // 
      this.dgvGestVoeux.AllowUserToAddRows = false;
      this.dgvGestVoeux.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvGestVoeux.Location = new System.Drawing.Point(240, 251);
      this.dgvGestVoeux.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.dgvGestVoeux.Name = "dgvGestVoeux";
      this.dgvGestVoeux.RowTemplate.Height = 28;
      this.dgvGestVoeux.Size = new System.Drawing.Size(812, 393);
      this.dgvGestVoeux.TabIndex = 4;
      this.dgvGestVoeux.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGestVoeux_CellDoubleClick);
      // 
      // btnAccueil
      // 
      this.btnAccueil.BackgroundImage = global::PPE4.Properties.Resources.gris;
      this.btnAccueil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnAccueil.Location = new System.Drawing.Point(1093, 576);
      this.btnAccueil.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.btnAccueil.Name = "btnAccueil";
      this.btnAccueil.Size = new System.Drawing.Size(180, 68);
      this.btnAccueil.TabIndex = 13;
      this.btnAccueil.Text = "Gestion des régions";
      this.btnAccueil.UseVisualStyleBackColor = true;
      this.btnAccueil.Click += new System.EventHandler(this.btnAccueil_Click);
      // 
      // btnHisto
      // 
      this.btnHisto.BackgroundImage = global::PPE4.Properties.Resources.gris;
      this.btnHisto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnHisto.Location = new System.Drawing.Point(1093, 485);
      this.btnHisto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.btnHisto.Name = "btnHisto";
      this.btnHisto.Size = new System.Drawing.Size(180, 68);
      this.btnHisto.TabIndex = 14;
      this.btnHisto.Text = "Historique des affectations";
      this.btnHisto.UseVisualStyleBackColor = true;
      this.btnHisto.Click += new System.EventHandler(this.btnHisto_Click);
      // 
      // label5
      // 
      this.label5.BackColor = System.Drawing.Color.Transparent;
      this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label5.ForeColor = System.Drawing.Color.Navy;
      this.label5.Location = new System.Drawing.Point(427, 35);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(464, 40);
      this.label5.TabIndex = 15;
      this.label5.Text = "Gestion des affectations de poste";
      this.label5.Click += new System.EventHandler(this.label5_Click);
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.BackColor = System.Drawing.Color.Transparent;
      this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label4.ForeColor = System.Drawing.Color.Navy;
      this.label4.Location = new System.Drawing.Point(1152, 12);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(43, 22);
      this.label4.TabIndex = 16;
      this.label4.Text = "aaa";
      // 
      // cbUser
      // 
      this.cbUser.FormattingEnabled = true;
      this.cbUser.Location = new System.Drawing.Point(118, 66);
      this.cbUser.Name = "cbUser";
      this.cbUser.Size = new System.Drawing.Size(161, 28);
      this.cbUser.TabIndex = 17;
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label3.Location = new System.Drawing.Point(350, 15);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(78, 22);
      this.label3.TabIndex = 19;
      this.label3.Text = "Filtrage";
      // 
      // panel2
      // 
      this.panel2.Controls.Add(this.btnFiltre);
      this.panel2.Controls.Add(this.cbReg);
      this.panel2.Controls.Add(this.label6);
      this.panel2.Controls.Add(this.lbUserU);
      this.panel2.Controls.Add(this.label3);
      this.panel2.Controls.Add(this.cbUser);
      this.panel2.Location = new System.Drawing.Point(240, 90);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(812, 144);
      this.panel2.TabIndex = 20;
      // 
      // btnFiltre
      // 
      this.btnFiltre.BackgroundImage = global::PPE4.Properties.Resources.gris;
      this.btnFiltre.Location = new System.Drawing.Point(660, 61);
      this.btnFiltre.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.btnFiltre.Name = "btnFiltre";
      this.btnFiltre.Size = new System.Drawing.Size(118, 41);
      this.btnFiltre.TabIndex = 5;
      this.btnFiltre.Text = "Valider";
      this.btnFiltre.UseVisualStyleBackColor = true;
      this.btnFiltre.Click += new System.EventHandler(this.btnFiltre_Click);
      // 
      // cbReg
      // 
      this.cbReg.FormattingEnabled = true;
      this.cbReg.Location = new System.Drawing.Point(445, 64);
      this.cbReg.Name = "cbReg";
      this.cbReg.Size = new System.Drawing.Size(170, 28);
      this.cbReg.TabIndex = 22;
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(352, 69);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(68, 20);
      this.label6.TabIndex = 21;
      this.label6.Text = "Région :";
      this.label6.Click += new System.EventHandler(this.label6_Click);
      // 
      // lbUserU
      // 
      this.lbUserU.AutoSize = true;
      this.lbUserU.Location = new System.Drawing.Point(24, 71);
      this.lbUserU.Name = "lbUserU";
      this.lbUserU.Size = new System.Drawing.Size(88, 20);
      this.lbUserU.TabIndex = 20;
      this.lbUserU.Text = "Utilisateur :";
      // 
      // gestionAffect
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
      this.ClientSize = new System.Drawing.Size(1338, 681);
      this.Controls.Add(this.panel2);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.label5);
      this.Controls.Add(this.btnHisto);
      this.Controls.Add(this.btnAccueil);
      this.Controls.Add(this.dgvGestVoeux);
      this.Controls.Add(this.panel1);
      this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.Name = "gestionAffect";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "gestionAffect";
      this.Load += new System.EventHandler(this.gestionAffect_Load);
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgvGestVoeux)).EndInit();
      this.panel2.ResumeLayout(false);
      this.panel2.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Button btnDecon;
    private System.Windows.Forms.Label lbUser;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.PictureBox pictureBox1;
    private System.Windows.Forms.DataGridView dgvGestVoeux;
    private System.Windows.Forms.Button btnAccueil;
    private System.Windows.Forms.Button btnHisto;
    private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    private System.Windows.Forms.ComboBox cbUser;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.ComboBox cbReg;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label lbUserU;
    private System.Windows.Forms.Button btnFiltre;
  }
}