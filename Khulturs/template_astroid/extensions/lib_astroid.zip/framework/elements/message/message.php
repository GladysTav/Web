<?php defined('_JEXEC') or die; ?>
<jdoc:include type="message" />